/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author josep
 */
@Entity
@Table(name = "OrdersLog", catalog = "ProyectoFinal", schema = "dbo")
@NamedQueries({
    @NamedQuery(name = "OrdersLog.findAll", query = "SELECT o FROM OrdersLog o"),
    @NamedQuery(name = "OrdersLog.findByIdOrderLog", query = "SELECT o FROM OrdersLog o WHERE o.idOrderLog = :idOrderLog"),
    @NamedQuery(name = "OrdersLog.findByIdOrder", query = "SELECT o FROM OrdersLog o WHERE o.idOrder = :idOrder"),
    @NamedQuery(name = "OrdersLog.findByStatus", query = "SELECT o FROM OrdersLog o WHERE o.status = :status"),
    @NamedQuery(name = "OrdersLog.findByLastModification", query = "SELECT o FROM OrdersLog o WHERE o.lastModification = :lastModification")})
public class OrdersLog implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idOrderLog")
    private Integer idOrderLog;
    @Basic(optional = false)
    @Column(name = "idOrder")
    private int idOrder;
    @Basic(optional = false)
    @Column(name = "status")
    private Character status;
    @Basic(optional = false)
    @Column(name = "lastModification")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModification;

    public OrdersLog() {
    }

    public OrdersLog(Integer idOrderLog) {
        this.idOrderLog = idOrderLog;
    }

    public OrdersLog(Integer idOrderLog, int idOrder, Character status, Date lastModification) {
        this.idOrderLog = idOrderLog;
        this.idOrder = idOrder;
        this.status = status;
        this.lastModification = lastModification;
    }

    public Integer getIdOrderLog() {
        return idOrderLog;
    }

    public void setIdOrderLog(Integer idOrderLog) {
        Integer oldIdOrderLog = this.idOrderLog;
        this.idOrderLog = idOrderLog;
        changeSupport.firePropertyChange("idOrderLog", oldIdOrderLog, idOrderLog);
    }

    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        int oldIdOrder = this.idOrder;
        this.idOrder = idOrder;
        changeSupport.firePropertyChange("idOrder", oldIdOrder, idOrder);
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        Character oldStatus = this.status;
        this.status = status;
        changeSupport.firePropertyChange("status", oldStatus, status);
    }

    public Date getLastModification() {
        return lastModification;
    }

    public void setLastModification(Date lastModification) {
        Date oldLastModification = this.lastModification;
        this.lastModification = lastModification;
        changeSupport.firePropertyChange("lastModification", oldLastModification, lastModification);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idOrderLog != null ? idOrderLog.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OrdersLog)) {
            return false;
        }
        OrdersLog other = (OrdersLog) object;
        if ((this.idOrderLog == null && other.idOrderLog != null) || (this.idOrderLog != null && !this.idOrderLog.equals(other.idOrderLog))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Interfaz.OrdersLog[ idOrderLog=" + idOrderLog + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
