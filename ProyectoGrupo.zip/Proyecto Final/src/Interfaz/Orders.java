/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author josep
 */
@Entity
@Table(name = "Orders", catalog = "ProyectoFinal", schema = "dbo")
@NamedQueries({
    @NamedQuery(name = "Orders.findAll", query = "SELECT o FROM Orders o"),
    @NamedQuery(name = "Orders.findByIdOrder", query = "SELECT o FROM Orders o WHERE o.idOrder = :idOrder"),
    @NamedQuery(name = "Orders.findByIdCustomer", query = "SELECT o FROM Orders o WHERE o.idCustomer = :idCustomer"),
    @NamedQuery(name = "Orders.findByInvoiceNumber", query = "SELECT o FROM Orders o WHERE o.invoiceNumber = :invoiceNumber"),
    @NamedQuery(name = "Orders.findByIdUser", query = "SELECT o FROM Orders o WHERE o.idUser = :idUser"),
    @NamedQuery(name = "Orders.findByCreatedDate", query = "SELECT o FROM Orders o WHERE o.createdDate = :createdDate"),
    @NamedQuery(name = "Orders.findByStatus", query = "SELECT o FROM Orders o WHERE o.status = :status"),
    @NamedQuery(name = "Orders.findByLastModification", query = "SELECT o FROM Orders o WHERE o.lastModification = :lastModification"),
    @NamedQuery(name = "Orders.findByIdCarrier", query = "SELECT o FROM Orders o WHERE o.idCarrier = :idCarrier")})
public class Orders implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idOrder")
    private Integer idOrder;
    @Basic(optional = false)
    @Column(name = "idCustomer")
    private int idCustomer;
    @Basic(optional = false)
    @Column(name = "invoiceNumber")
    private String invoiceNumber;
    @Basic(optional = false)
    @Column(name = "idUser")
    private int idUser;
    @Basic(optional = false)
    @Column(name = "createdDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Basic(optional = false)
    @Column(name = "status")
    private short status;
    @Basic(optional = false)
    @Column(name = "lastModification")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModification;
    @Column(name = "idCarrier")
    private Integer idCarrier;

    public Orders() {
    }

    public Orders(Integer idOrder) {
        this.idOrder = idOrder;
    }

    public Orders(Integer idOrder, int idCustomer, String invoiceNumber, int idUser, Date createdDate, short status, Date lastModification) {
        this.idOrder = idOrder;
        this.idCustomer = idCustomer;
        this.invoiceNumber = invoiceNumber;
        this.idUser = idUser;
        this.createdDate = createdDate;
        this.status = status;
        this.lastModification = lastModification;
    }

    public Integer getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(Integer idOrder) {
        Integer oldIdOrder = this.idOrder;
        this.idOrder = idOrder;
        changeSupport.firePropertyChange("idOrder", oldIdOrder, idOrder);
    }

    public int getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(int idCustomer) {
        int oldIdCustomer = this.idCustomer;
        this.idCustomer = idCustomer;
        changeSupport.firePropertyChange("idCustomer", oldIdCustomer, idCustomer);
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        String oldInvoiceNumber = this.invoiceNumber;
        this.invoiceNumber = invoiceNumber;
        changeSupport.firePropertyChange("invoiceNumber", oldInvoiceNumber, invoiceNumber);
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        int oldIdUser = this.idUser;
        this.idUser = idUser;
        changeSupport.firePropertyChange("idUser", oldIdUser, idUser);
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        Date oldCreatedDate = this.createdDate;
        this.createdDate = createdDate;
        changeSupport.firePropertyChange("createdDate", oldCreatedDate, createdDate);
    }

    public short getStatus() {
        return status;
    }

    public void setStatus(short status) {
        short oldStatus = this.status;
        this.status = status;
        changeSupport.firePropertyChange("status", oldStatus, status);
    }

    public Date getLastModification() {
        return lastModification;
    }

    public void setLastModification(Date lastModification) {
        Date oldLastModification = this.lastModification;
        this.lastModification = lastModification;
        changeSupport.firePropertyChange("lastModification", oldLastModification, lastModification);
    }

    public Integer getIdCarrier() {
        return idCarrier;
    }

    public void setIdCarrier(Integer idCarrier) {
        Integer oldIdCarrier = this.idCarrier;
        this.idCarrier = idCarrier;
        changeSupport.firePropertyChange("idCarrier", oldIdCarrier, idCarrier);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idOrder != null ? idOrder.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Orders)) {
            return false;
        }
        Orders other = (Orders) object;
        if ((this.idOrder == null && other.idOrder != null) || (this.idOrder != null && !this.idOrder.equals(other.idOrder))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Interfaz.Orders[ idOrder=" + idOrder + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
