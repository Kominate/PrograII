/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author josep
 */
@Embeddable
public class CountyPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "idState")
    private short idState;
    @Basic(optional = false)
    @Column(name = "idCounty")
    private short idCounty;

    public CountyPK() {
    }

    public CountyPK(short idState, short idCounty) {
        this.idState = idState;
        this.idCounty = idCounty;
    }

    public short getIdState() {
        return idState;
    }

    public void setIdState(short idState) {
        this.idState = idState;
    }

    public short getIdCounty() {
        return idCounty;
    }

    public void setIdCounty(short idCounty) {
        this.idCounty = idCounty;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idState;
        hash += (int) idCounty;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountyPK)) {
            return false;
        }
        CountyPK other = (CountyPK) object;
        if (this.idState != other.idState) {
            return false;
        }
        if (this.idCounty != other.idCounty) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Interfaz.CountyPK[ idState=" + idState + ", idCounty=" + idCounty + " ]";
    }
    
}
