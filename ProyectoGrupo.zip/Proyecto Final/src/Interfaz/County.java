/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaz;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author josep
 */
@Entity
@Table(name = "County", catalog = "ProyectoFinal", schema = "dbo")
@NamedQueries({
    @NamedQuery(name = "County.findAll", query = "SELECT c FROM County c"),
    @NamedQuery(name = "County.findByIdState", query = "SELECT c FROM County c WHERE c.countyPK.idState = :idState"),
    @NamedQuery(name = "County.findByIdCounty", query = "SELECT c FROM County c WHERE c.countyPK.idCounty = :idCounty"),
    @NamedQuery(name = "County.findByCountyName", query = "SELECT c FROM County c WHERE c.countyName = :countyName"),
    @NamedQuery(name = "County.findByActive", query = "SELECT c FROM County c WHERE c.active = :active")})
public class County implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CountyPK countyPK;
    @Basic(optional = false)
    @Column(name = "countyName")
    private String countyName;
    @Basic(optional = false)
    @Column(name = "active")
    private boolean active;

    public County() {
    }

    public County(CountyPK countyPK) {
        this.countyPK = countyPK;
    }

    public County(CountyPK countyPK, String countyName, boolean active) {
        this.countyPK = countyPK;
        this.countyName = countyName;
        this.active = active;
    }

    public County(short idState, short idCounty) {
        this.countyPK = new CountyPK(idState, idCounty);
    }

    public CountyPK getCountyPK() {
        return countyPK;
    }

    public void setCountyPK(CountyPK countyPK) {
        this.countyPK = countyPK;
    }

    public String getCountyName() {
        return countyName;
    }

    public void setCountyName(String countyName) {
        String oldCountyName = this.countyName;
        this.countyName = countyName;
        changeSupport.firePropertyChange("countyName", oldCountyName, countyName);
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        boolean oldActive = this.active;
        this.active = active;
        changeSupport.firePropertyChange("active", oldActive, active);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countyPK != null ? countyPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof County)) {
            return false;
        }
        County other = (County) object;
        if ((this.countyPK == null && other.countyPK != null) || (this.countyPK != null && !this.countyPK.equals(other.countyPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Interfaz.County[ countyPK=" + countyPK + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
