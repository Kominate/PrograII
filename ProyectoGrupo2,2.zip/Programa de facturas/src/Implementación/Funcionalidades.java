/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementación;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.util.Random;
import java.util.Calendar;
import java.text.DecimalFormat;


/**
 *
 * @author josep
 */
public class Funcionalidades {
    public void CargarArticulos(String matriz[][]){
        matriz [0][0]="A101";
        matriz [0][1]="Atún enlatado";
        matriz [0][2]="40";
        matriz [0][3]="500.00";
        
        matriz [1][0]="A102";
        matriz [1][1]="Carne de res";
        matriz [1][2]="40";
        matriz [1][3]="1471.00";

        matriz [2][0]="A103";
        matriz [2][1]="Carne de cerdo";
        matriz [2][2]="40";
        matriz [2][3]="1150.00";
        
        
        matriz [3][0]="A104";
        matriz [3][1]="Queso blanco";
        matriz [3][2]="40";
        matriz [3][3]="1407.00";
        
        matriz [4][0]="A105";
        matriz [4][1]="Mortadela";
        matriz [4][2]="40";
        matriz [4][3]="735.00";
        
        matriz [5][0]="A106";
        matriz [5][1]="Sardina";
        matriz [5][2]="40";
        matriz [5][3]="336.00";
        
        matriz [6][0]="A107";
        matriz [6][1]="Leche";
        matriz [6][2]="40";
        matriz [6][3]="459.00";
 
        matriz [7][0]="A108";
        matriz [7][1]="Lenteja";
        matriz [7][2]="40";
        matriz [7][3]="430.00";

        matriz [8][0]="A109";
        matriz [8][1]="Frijoles";
        matriz [8][2]="40";
        matriz [8][3]="456.00";

        matriz [9][0]="A110";
        matriz [9][1]="Arroz";
        matriz [9][2]="40";
        matriz [9][3]="656.00";
        
        matriz [10][0]="A111";
        matriz [10][1]="Aceite";
        matriz [10][2]="40";
        matriz [10][3]="612.00";
        
        matriz [11][0]="A112";
        matriz [11][1]="Azucar";
        matriz [11][2]="40";
        matriz [11][3]="350.00";
        
        matriz [12][0]="A113";
        matriz [12][1]="Café";
        matriz [12][2]="40";
        matriz [12][3]="600.00";
        
        matriz [13][0]="A114";
        matriz [13][1]="Salsa de tomate";
        matriz [13][2]="40";
        matriz [13][3]="300.00";
        
        matriz [14][0]="A115";
        matriz [14][1]="Sal";
        matriz [14][2]="40";
        matriz [14][3]="215.00";

        
    }
    public void CargarTabla1(JTable T1,String matriz[][]){
       int i=0;
        DefaultTableModel tabla = new DefaultTableModel();
        
        tabla.addColumn("Código de producto");
        tabla.addColumn("Nombre de producto");
        tabla.addColumn("Cantidad");
        tabla.addColumn("Precio");
        
        tabla.setRowCount(matriz.length);
        while (i < matriz.length)
            
        {
            tabla.setValueAt(matriz[i][0], i, 0);
            tabla.setValueAt(matriz[i][1], i, 1);
            tabla.setValueAt(matriz[i][2], i, 2);
            tabla.setValueAt(matriz[i][3], i, 3);
            i++;
        }
        T1.setModel(tabla);
        
       
    }
    public void Modificarregistro(String matriz[][],String Código,String Cantidad,String Precio){
        int indice,pos = -1;
        for(indice=0;indice < matriz.length;indice++){
            if(matriz[indice][0].equals(Código)){
                pos = indice;
            }
        }
        if(pos == -1){
            JOptionPane.showMessageDialog(null,"Lo siento, entraste un código inexistente en el inventario");
        }else{
            matriz[pos][2] = Cantidad;
            matriz[pos][3] = Precio + ".00";
        }
        
    }
    public void Borrararticulo(String matriz[][],String Código){
      int indice,pos = -1;
        for(indice=0;indice < matriz.length;indice++){
            if(matriz[indice][0].equals(Código)){
            pos=indice;
            }
        }
        if(pos == -1){
            JOptionPane.showMessageDialog(null,"Lo siento, entraste un código inexistente en el inventario");
        }else{
            matriz[pos][0] = " ";
            matriz[pos][1] = " ";
            matriz[pos][2] = " ";
            matriz[pos][3] = " ";
        }  
    }
    public void Agregarregistro(String matriz[][],String Código,String Articulo,String Cantidad, String Precio){
       int indice, pos = -1;
        for(indice=0;indice < matriz.length;indice++){
            if(matriz[indice][0].equals(" ")){
            pos = indice;
            }else if(matriz[indice][0].equals(Código)){
                pos = -2;
            }
        }
        if(pos == -2){
            JOptionPane.showMessageDialog(null,"Este código ya existe en el inventario, escoja otro que no este tomado o borre el registro de este");
        }else if( pos == -1){
            JOptionPane.showMessageDialog(null,"Lo siento, entraste un código inexistente en el inventario");
        }
        else{
          matriz[pos][0] = Código;
          matriz[pos][1] = Articulo;
          matriz[pos][2] = Cantidad;
          matriz[pos][3] = Precio + ".00";   
        }
    }
    public void Capturarregistro(String matriz[][],String Código, String Cantidad,DefaultTableModel Compras){
        int indice, pos = -1,indice2;
         Double aux,Subtotal;       
        for(indice=0;indice < matriz.length;indice++){
            if(matriz[indice][0].equals(Código)){
            pos = indice;
            }
        }
        for(indice2=0;indice2 < Compras.getRowCount();indice2++){
            if(Compras.getValueAt(indice2,0).equals(Código)){
               pos = -2;
            }
        }
        if( pos == -1){
          JOptionPane.showMessageDialog(null,"Lo siento, entraste un código inexistente en el inventario");
        }else if(Compras.getRowCount() == 6){
          JOptionPane.showMessageDialog(null,"Ya no queda más espacio en la factura");  
        }else if(pos == -2){
            JOptionPane.showMessageDialog(null,"Este producto ya esta registrado en la factura");
        }else{
            aux = Double.parseDouble(matriz[pos][3]);
            Subtotal = Double.parseDouble(Cantidad) * aux;
        Compras.addRow(new Object[]{Código,matriz[pos][1],Cantidad,matriz[pos][3],Subtotal});
        }
    }
    public String Generaraleatorio(String Numero){
        int indice;
        Random aleatorio =  new Random();
        StringBuffer constructor = new StringBuffer();
        char [] caracteres = "0123456789".toCharArray();
        int longitud = caracteres.length;
        for(indice = 0; indice < 6 ; indice++){
            constructor.append(caracteres[aleatorio.nextInt(longitud)]);
        }
        return "110" + constructor.toString();
        
    }
    public Double Subtotal(DefaultTableModel Compras,String Subtotal){
        int indice;
        double Aux,Sub = 0;
        for(indice=0;indice < Compras.getRowCount();indice++){
            Aux = Double.parseDouble(Compras.getValueAt(indice,4).toString());
            Sub += Aux;
        }
        return Sub;
        
    }
    public Double iva(DefaultTableModel Compras,String IVA,String subtotal){
        double iva = 0.13,Aux;
        Aux = Double.parseDouble(subtotal) * iva;
        return Aux;
        
    }
    public Double total(DefaultTableModel Compras,String subtotal,String IVA,String Total){
        double Aux;
        Aux = Double.parseDouble(subtotal) + Double.parseDouble(IVA);
        return Aux;
    }
    public String fecha(String date){
        Calendar actual = Calendar.getInstance();
        int año = actual.get(Calendar.YEAR),mes = actual.get(Calendar.MONTH),dia = actual.get(Calendar.DAY_OF_MONTH);
        String Aux = "";
        
        Aux = Integer.toString(año) + "/" + Integer.toString(mes) + "/" + Integer.toString(dia);
        return Aux;
    }
    
    public void Guardarhistorico(DefaultTableModel Compras,DefaultTableModel Historico,String Cédula, String Telefono,String Total, String Código,String Fecha,String dinero){
        DecimalFormat decim = new DecimalFormat("#.00");
        int Amount = 0,Aux,indice,pos = 0,indice2;
        Double Ganancias;
        for(indice=0;indice < Compras.getRowCount();indice++){
            Aux = Integer.parseInt(Compras.getValueAt(indice,2).toString());
            Amount += Aux;
        }
        for(indice2 = 0;indice2 < Historico.getRowCount();indice2++){
            if(Historico.getValueAt(indice2,1).equals(Código)){
                pos = -1;
            }
        }
        if(pos == -1){
        JOptionPane.showMessageDialog(null,"Ya existe una factura con este código");
    }else if(Historico.getRowCount() == 20){
        JOptionPane.showMessageDialog(null,"Ya no se pueden hacer más compras");
    }else if(Double.parseDouble(dinero) < Double.parseDouble(Total)){
        JOptionPane.showMessageDialog(null,"No tienes el dinero suficiente para hacer la compra");
    }else{
            Historico.addRow(new Object[]{Fecha,Código,Cédula,Telefono,Amount,Total});
            Compras.setRowCount(0);
            Ganancias = Double.parseDouble(dinero) - Double.parseDouble(Total);
            JOptionPane.showMessageDialog(null,"Las ganancias obtenidas durante esta transacción fueron de:" + decim.format(Ganancias));
        }
    }
    public Double ganancias(DefaultTableModel Historico,String ganancia){
        int indice;
        double Aux,Total = 0;
        for(indice = 0; indice < Historico.getRowCount();indice++){
            Aux = Double.parseDouble(Historico.getValueAt(indice,5).toString());
            Total += Aux;
        }
        return Total;
    }
    public void Quitarproducto(DefaultTableModel Compras,String Código){
        int indice;
        for(indice=0;indice<Compras.getRowCount();indice++){
            if(Compras.getValueAt(indice,0).equals(Código)){
            Compras.removeRow(indice);
        }
        }
    }
    public void descontar(String matriz[][],DefaultTableModel Compras){
        int indice,indice2,aux,aux2,res;
        for(indice = 0; indice < Compras.getRowCount();indice++){
            for(indice2=0;indice2 < matriz.length;indice2++){
                if(Compras.getValueAt(indice,0).equals(matriz[indice2][0])){
                    aux = Integer.parseInt(matriz[indice2][2]);
                    aux2 = Integer.parseInt(Compras.getValueAt(indice,2).toString());
                    res = aux - aux2;
                    matriz[indice2][2] = Integer.toString(res);
                }
            }
        }
    }
    
}
